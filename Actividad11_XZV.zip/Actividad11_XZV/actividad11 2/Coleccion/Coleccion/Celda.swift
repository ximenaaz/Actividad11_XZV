//
//  Celda.swift
//  Coleccion
//
//  Created by alicharlie on 11/05/16.
//  Copyright © 2016 codepix. All rights reserved.
//

import UIKit

class Celda: UICollectionViewCell {
    @IBOutlet weak var imagenNum: UIImageView!
}
